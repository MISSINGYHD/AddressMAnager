package com.yhd.addressmanager.activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ListView;

import com.yhd.addressmanager.R;
import com.yhd.addressmanager.adapter.AddressAdapter;
import com.yhd.addressmanager.model.AddressList;

import java.util.ArrayList;
import java.util.List;


/**
 * ================================
 * <p>
 * 作  者：杨华东
 * <p>
 * 版本号：1.0
 * <p>
 * 创建日期：2016/8/1  13:01
 * <p>
 * 描  述：收货地址
 * <p>
 * ================================
 */
public class AddressActivity extends Activity {

    private ListView lvAddress;//收货地址
    private Button btnIncress;//新增收货地址

    private List<AddressList> list = new ArrayList<AddressList>();
    private AddressAdapter adapter;
    private ContentResolver resolver;
    private Uri uri = Uri
            .parse("content://com.yhd.addressmanager.contentprovider.AddressContentProvider");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
    }

    private void initView() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_address);
        lvAddress = (ListView) findViewById(R.id.lv_address);
        btnIncress = (Button) findViewById(R.id.bt_incress);
        btnIncress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddressActivity.this, NewAddressActivity.class));
            }
        });
        resolver = getContentResolver();
        adapter = new AddressAdapter(this, list);
        lvAddress.setAdapter(adapter);
        show();
    }

    public void show() {
        list.clear();
        Cursor cursor = resolver.query(uri, null, null, null, null);
        while (cursor.moveToNext()) {
            AddressList address = new AddressList();
            int num = cursor.getInt(cursor.getColumnIndex("num"));
            int upstair = cursor.getInt(cursor.getColumnIndex("upstair"));
            if (num == 1) {
                address.setFlag(true);
            } else {
                address.setFlag(false);
            }
            if (upstair == 1) {
                address.setUpstair(true);
            } else {
                address.setUpstair(false);
            }

            address.setId(cursor.getString(cursor.getColumnIndex("_id")));
            address.setName(cursor.getString(cursor.getColumnIndex("name")));
            address.setTel(cursor.getString(cursor.getColumnIndex("tel")));
            address.setAddress(cursor.getString(cursor.getColumnIndex("address")));
            address.setFlower(cursor.getString(cursor.getColumnIndex("flower")));
            address.setProvinceid(cursor.getInt(cursor.getColumnIndex("province")));
            address.setCityid(cursor.getInt(cursor.getColumnIndex("city")));
            address.setCountryid(cursor.getInt(cursor.getColumnIndex("country")));
            list.add(address);
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        show();
    }
}
