package com.yhd.addressmanager.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.yhd.addressmanager.R;
import com.yhd.addressmanager.activity.UpdataAddressActivity;
import com.yhd.addressmanager.model.AddressList;

import java.util.List;

/**
 * ================================
 * <p>
 * 作  者：杨华东
 * <p>
 * 版本号：1.0
 * <p>
 * 创建日期：2016/8/9  9:17
 * <p>
 * 描  述：地址适配器
 * <p>
 * ================================
 */
public class AddressAdapter extends BaseAdapter {

    private Context context;
    private List<AddressList> list;

    public AddressAdapter(Context context, List<AddressList> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder vh;
        if (convertView == null) {
            vh = new ViewHolder();
            convertView = View.inflate(context, R.layout.item_address, null);
            vh.lv_name = (TextView) convertView.findViewById(R.id.tv_zhangsan);
            vh.lv_tel = (TextView) convertView.findViewById(R.id.tv_phone);
            vh.lv_address = (TextView) convertView.findViewById(R.id.tv_address);
            vh.iv_gou = (ImageView) convertView.findViewById(R.id.iv_gou);
            convertView.setTag(vh);
        }
        vh = (ViewHolder) convertView.getTag();
        vh.lv_name.setText(list.get(position).getName());
        vh.lv_tel.setText(list.get(position).getTel());
        vh.lv_address.setText(list.get(position).getAddress());
        if (list.get(position).getFlag()) {
            vh.lv_name.setTextColor(context.getResources().getColor(R.color.white));
            vh.lv_tel.setTextColor(context.getResources().getColor(R.color.white));
            vh.lv_address.setTextColor(context.getResources().getColor(R.color.white));
            convertView.setBackgroundColor(context.getResources().getColor(R.color.darkgray));
            vh.iv_gou.setVisibility(View.VISIBLE);
        } else {
            vh.lv_name.setTextColor(context.getResources().getColor(R.color.darkgray));
            vh.lv_tel.setTextColor(context.getResources().getColor(R.color.darkgray));
            vh.lv_address.setTextColor(context.getResources().getColor(R.color.darkgray));
            convertView.setBackgroundColor(context.getResources().getColor(R.color.white));
            vh.iv_gou.setVisibility(View.INVISIBLE);
        }
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdataAddressActivity.class);
                intent.putExtra("address", list.get(position));
                context.startActivity(intent);
            }
        });
        return convertView;
    }

    class ViewHolder {
        TextView lv_name;
        TextView lv_tel;
        TextView lv_address;
        ImageView iv_gou;
    }
}
