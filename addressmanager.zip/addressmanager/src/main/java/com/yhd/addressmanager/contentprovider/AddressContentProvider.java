package com.yhd.addressmanager.contentprovider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.Nullable;

import com.yhd.addressmanager.db.AddressDB;

/**
 * ================================
 * <p>
 * 作  者：杨华东
 * <p>
 * 版本号：1.0
 * <p>
 * 创建日期：2016/8/9  9:12
 * <p>
 * 描  述：地址数据信息管理
 * <p>
 * ================================
 */
public class AddressContentProvider extends ContentProvider {

    private SQLiteDatabase db;

    @Override
    public boolean onCreate() {
        AddressDB helper = new AddressDB(this.getContext());
        db = helper.getReadableDatabase();
        return false;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Cursor cursor = db.query("address", projection, selection, selectionArgs, null, null, sortOrder);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        db.insert("address", null, values);
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        db.delete("address", selection, selectionArgs);
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        db.update("address", values, selection, selectionArgs);
        return 0;
    }
}
