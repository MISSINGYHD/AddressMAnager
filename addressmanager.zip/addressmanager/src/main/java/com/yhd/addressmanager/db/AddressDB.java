package com.yhd.addressmanager.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * ================================
 * <p/>
 * 作  者：杨华东
 * <p/>
 * 版本号：1.0
 * <p/>
 * 创建日期：2016/8/9  9:08
 * <p/>
 * 描  述：地址数据库
 * <p/>
 * ================================
 */
public class AddressDB extends SQLiteOpenHelper {

    public AddressDB(Context context) {
        super(context, "Address.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table address(_id integer primary key autoincrement,name varchar(0),tel varchar(0),address varchar(0),flower varchar(0),num integer,upstair integer,province integer,city integer,country integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
