package com.yhd.addressmanager.model;

import java.io.Serializable;

/**
 * ================================
 * <p/>
 * 作  者：杨华东
 * <p/>
 * 版本号：1.0
 * <p/>
 * 创建日期：2016/8/8  16:22
 * <p/>
 * 描  述：地址数据管理
 * <p/>
 * ================================
 */
public class AddressList implements Serializable {
    private String id;
    private String name;
    private String tel;
    private String address;
    private String flower;
    private Boolean upstair;
    private Boolean flag;
    private int provinceid;
    private int cityid;
    private int countryid;

    public Boolean getUpstair() {
        return upstair;
    }

    public void setUpstair(Boolean upstair) {
        this.upstair = upstair;
    }

    public int getProvinceid() {
        return provinceid;
    }

    public void setProvinceid(int provinceid) {
        this.provinceid = provinceid;
    }

    public int getCityid() {
        return cityid;
    }

    public void setCityid(int cityid) {
        this.cityid = cityid;
    }

    public int getCountryid() {
        return countryid;
    }

    public void setCountryid(int countryid) {
        this.countryid = countryid;
    }

    public String getFlower() {
        return flower;
    }

    public void setFlower(String flower) {
        this.flower = flower;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean falg) {
        this.flag = falg;
    }

    public AddressList() {
        super();
    }

    @Override
    public String toString() {
        return "AddressList{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", tel='" + tel + '\'' +
                ", address='" + address + '\'' +
                ", flower='" + flower + '\'' +
                ", upstair=" + upstair +
                ", flag=" + flag +
                ", provinceid=" + provinceid +
                ", cityid=" + cityid +
                ", countryid=" + countryid +
                '}';
    }
}