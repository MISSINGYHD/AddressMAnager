package com.yhd.addressmanager.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.yhd.addressmanager.R;


/**
 * Created by yhd on 2016/3/15.
 */
public class MyToggBtn extends View implements View.OnClickListener {

    private Paint mPaint;
    private Bitmap bitbackground;
    private Bitmap slceground;
    private float btnleft;

    private boolean currState;

    public MyToggBtn(Context context) {
        super(context);
    }

    public MyToggBtn(Context context, AttributeSet attrs) {
        super(context, attrs);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        initView();
    }


    private void initView() {
        bitbackground = BitmapFactory.decodeResource(getResources(), R.mipmap.switch_background);
        slceground = BitmapFactory.decodeResource(getResources(), R.mipmap.slide_button);
        setOnClickListener(this);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(bitbackground.getWidth());
        int height = MeasureSpec.getSize(bitbackground.getHeight());
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //绘制背景
        canvas.drawBitmap(bitbackground, 0, 0, mPaint);
        //绘制按钮
        canvas.drawBitmap(slceground, btnleft, 0, mPaint);
    }

    private boolean isDrag = false;

    @Override
    public void onClick(View v) {
        if (!isDrag) {
            currState = !currState;
            flushState();
        }
    }

    public boolean isOpened() {
        return currState;
    }

    public void isCurrState(boolean state) {
        isDrag = state;
        currState = state;
        flushState();
    }


    private void flushState() {
        if (currState) {
            btnleft = bitbackground.getWidth() - slceground.getWidth();
        } else {
            btnleft = 0;
        }
        flashView();
    }

    private int fristX;
    private int lastX;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                fristX = lastX = (int) event.getX();
                isDrag = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(event.getX() - fristX) > 2) {
                    isDrag = true;
                }
                int dis = (int) (event.getX() - lastX);
                lastX = (int) event.getX();
                btnleft = btnleft + dis;
                break;
            case MotionEvent.ACTION_UP:
                if (isDrag) {
                    int maxLeft = bitbackground.getWidth() - slceground.getWidth();
                    //根据左边的距离判断状态
                    if (btnleft >= maxLeft / 2) {
                        currState = true;
                    } else {
                        currState = false;
                    }
                    flushState();
                }
                break;
        }
        flashView();
        return true;
    }

    public void flashView() {
        int maxLeft = bitbackground.getWidth() - slceground.getWidth();
        btnleft = (btnleft > 0) ? btnleft : 0;
        btnleft = (btnleft < maxLeft) ? btnleft : maxLeft;
        invalidate();
    }
}
